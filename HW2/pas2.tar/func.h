#include <math.h>

double f0(double x, double y);
double fa(double x, double y);
double fb(double x, double y);
double fc(double x, double y);
double fd(double x, double y);
double fr(double x, double y);